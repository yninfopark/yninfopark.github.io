const btn=document.getElementById("langBtn");let lang="en";
function applyLanguage(){
 document.querySelectorAll("[data-en]").forEach(el=>{el.textContent=el.dataset[lang]});
 document.documentElement.lang=lang;
 btn.textContent=lang==="en"?"हिन्दी":"English";
}
btn.addEventListener("click",()=>{lang=lang==="en"?"hi":"en";applyLanguage()});
document.getElementById("year").textContent=new Date().getFullYear();
applyLanguage();
