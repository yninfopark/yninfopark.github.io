AWASTHI SERVICES - FREE WEBSITE
================================
Files:
- index.html : website
- style.css  : design
- script.js  : English/Hindi language switch

How to view:
1. Keep all three files in the same folder.
2. Double-click index.html to open it in your browser.

Free publishing:
- GitHub Pages can host these files free.
- Netlify can also host the folder free.

Business details included:
Phone/WhatsApp: 8318042257
Email: yninfopak@gmail.com
Location: Harrisganj, Kanpur, Uttar Pradesh
